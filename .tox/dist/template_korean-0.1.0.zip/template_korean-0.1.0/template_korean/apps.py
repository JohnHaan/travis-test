from __future__ import unicode_literals

from django.apps import AppConfig


class TemplateKoreanConfig(AppConfig):
    name = 'template_korean'
